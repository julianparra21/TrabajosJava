import javax.swing.JOptionPane;

/**
 * 
 * Cree un algoritmo que calcule e imprima lo que debe pagar un paciente a un
 * hospital debido a un tratamiento teniendo como entradas el costo del
 * tratamiento, el número de días de Hospitalización y el costo de los
 * medicamentos. Cada día de hospitalización cuesta $100000. Realice este
 * proceso para n cantidad de usuarios.
 * 
 * @author CHENAO
 *
 */
public class EjemploDoWhile {
	public static void main(String[] args) {
		int usuarios = Integer.parseInt(
				JOptionPane.showInputDialog("Ingrese el numero de pacientes de los que desea calcular el tratamiento"));
		int i = 0;

		do {
			int dias = Integer.parseInt(JOptionPane.showInputDialog("Ingrese los dias de hospitalizacion"));
			int costoTratamiento = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el costo del tratamiento"));
			int diasHospitalizacion = dias * 100000;
			int total = costoTratamiento + diasHospitalizacion;

			System.out.println("El total que debe pagar el paciente es: " + total);
			i++;
		} while (i < usuarios);
		System.out.println("Fin del programa");
	}
}
