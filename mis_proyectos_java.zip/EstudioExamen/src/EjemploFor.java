import javax.swing.JOptionPane;

public class EjemploFor {
	public static void main(String[] args) {
		int usuarios = Integer.parseInt(
				JOptionPane.showInputDialog("Ingrese el numero de pacientes de los que desea calcular el tratamiento"));
		for (int i = 0; i < usuarios; i++) {
			int dias = Integer.parseInt(JOptionPane.showInputDialog("Ingrese los dias de hospitalizacion"));
			int costoTratamiento = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el costo del tratamiento"));
			int diasHospitalizacion = dias * 100000;
			int total = costoTratamiento + diasHospitalizacion;
			System.out.println("El costo del tratamiento es: " + total);
		}

	}
}
