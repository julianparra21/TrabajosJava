import java.util.HashMap;
import java.util.Iterator;

import javax.swing.JOptionPane;

public class procesos {
 public procesos(){
	 trabajarConHashMap();
 }

private void trabajarConHashMap() {
	// TODO Auto-generated method stub
	HashMap<Integer, String> nombresMap=new HashMap<>();
	System.out.println(nombresMap.isEmpty());
	for (int i = 0; i < 4; i++) {
		int clave= Integer.parseInt(JOptionPane.showInputDialog("Ingres el documento"));
		String nombre=JOptionPane.showInputDialog("Ingrese el nombre");
		nombresMap.put(clave, nombre);
	}
	System.out.println(nombresMap.isEmpty());
	System.out.println(nombresMap);
	
	nombresMap.remove(111, "juan");
	
	Iterator<Integer>iterador=nombresMap.keySet().iterator();
	
	while(iterador.hasNext()) {
		Integer key=iterador.next();
		System.out.println(key+" - "+nombresMap.get(key));
		}
}
 
}
