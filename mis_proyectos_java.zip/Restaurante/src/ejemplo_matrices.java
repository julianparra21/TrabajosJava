import java.util.Iterator;

import javax.swing.JOptionPane;

public class ejemplo_matrices {

	public static void main(String[] args) {
		int numeros[]=new int [6];
		
		for (int i = 0; i < numeros.length; i++) {
			numeros[0]=Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero"));
		}
		
		
		System.out.println(numeros[2]);
		System.out.println("TAMAÑO "+ numeros.length);
		for (int i = 0; i < numeros.length; i++) {
			System.out.println(numeros[i]);
		}
		
		
	}

}
