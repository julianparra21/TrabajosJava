
public class ejercicio8 {
	public static void main(String[] args) {
		 int x[]= {1,2,3,4};
		 
		 int y[]= {2,5,7,8};
		 
		 int arregloFinal[]=new int[x.length];
		 arregloFinal[0]=x[0]+y[0];
		 arregloFinal[1]=x[1]+y[1];
		 arregloFinal[2]=x[2]+y[2];
		 arregloFinal[3]=x[3]+y[3];
		
		 
		
		}
	
}
