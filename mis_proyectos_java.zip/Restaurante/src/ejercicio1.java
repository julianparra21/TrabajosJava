import javax.swing.JOptionPane;
public class ejercicio1 {
public static void main(String args[]) {
	//Calcular el promedio de 3 notas de n estudiantes y almacenar en arreglos el nombre y la nota final de los estudiantes
	//Registrados. Determine si cada estudiante gana o pierde la materia, basado en sus notas finales. gana con 3.5 en adelante.
	int n=Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de estudiantes"));
	String nombres[]=new String[n];
	double notaFinal[]=new double[n];
	for (int i = 0; i < nombres.length; i++) {
		nombres[i]=JOptionPane.showInputDialog("Ingrese el nombre");
		double nota1=Double.parseDouble(JOptionPane.showInputDialog("ingrese la primera nota"));
		double nota2=Double.parseDouble(JOptionPane.showInputDialog("ingrese la segunda nota"));
		double nota3=Double.parseDouble(JOptionPane.showInputDialog("ingrese la tercera nota"));
		notaFinal[i]= (nota1+nota2+nota3)/3;
			
		System.out.println("el nombre del estudiante es: "+nombres[i]+" Y su nota final es: "+notaFinal[i] );
		
		if (notaFinal[i]>=3.5) {
			System.out.println("El estudiante gana la materia");
		}else {
			System.out.println("El estudiante pierde la materia");
		}
	}
	
	
	

	
}
}
