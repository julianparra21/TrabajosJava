import java.util.ArrayList;
import javax.swing.JOptionPane;
public class Ejemplo2 {
 public static void main(String[] args) {
	ArrayList<Integer>listnumeros= new ArrayList<Integer>();
	int tam=8;
	System.out.println(tam);
	
	for (int i = 0; i <tam; i++) {
		int valor=Integer.parseInt(JOptionPane.showInputDialog("ingrese un numero"));
		listnumeros.add(valor);
		System.out.println(listnumeros);
	}
	System.out.println("lista completa");
	System.out.println(listnumeros);
	listnumeros.add(100);
	System.out.println();
	
	for (int i = 0; i < listnumeros.size(); i++) {
		System.out.println(listnumeros.get(i)+"|");
	}
	System.out.println();
	System.out.println(listnumeros.get(5));
	
}
}
