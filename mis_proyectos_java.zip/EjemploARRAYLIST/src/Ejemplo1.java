import java.util.ArrayList;

public class Ejemplo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int x[]= new int[4];
	ArrayList<Integer>listnumeros=new ArrayList<Integer>();
	listnumeros.add(6);
	listnumeros.add(4);
	listnumeros.add(6);
	listnumeros.add(7);
	listnumeros.add(8);
	listnumeros.add(12);
	 int bandera=0;
	 
	 if (listnumeros.contains(6)) {
		 for (int i = 0; i <listnumeros.size(); i++) {
				if (listnumeros.get(i)==6) {
					System.out.println("si se encuentra el 6 en la posicion " +i);
					bandera=1;
				}	
				}
	}
	
	if (bandera==0) {
		System.out.println("no se encuentra el numero");
	}
	
	}

}
