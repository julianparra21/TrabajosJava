import java.util.ArrayList;

public class ejemplo3 {
public static void main(String[] args) {
	int x[]= new int[4];
	ArrayList<Integer>listnumeros=new ArrayList<Integer>();
	listnumeros.add(6);
	listnumeros.add(4);
	listnumeros.add(6);
	listnumeros.add(7);
	listnumeros.add(8);
	listnumeros.add(12);
	
	System.out.println(listnumeros);
	listnumeros.remove(6);
	 
	
}
}
