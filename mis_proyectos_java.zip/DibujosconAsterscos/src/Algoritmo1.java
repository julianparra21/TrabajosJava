import java.util.Scanner;
public class Algoritmo1 {
	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		System.out.println("introduzca el lado del cuadrado: ");
		int lado = teclado.nextInt();
		teclado.close();

		System.out.println();
		for (int row = 1; row <= lado; row++) {
			for (int col = 1; col <= lado; col++) {
				if (row == 1 || row == lado || col == 1 || col == lado) {
					System.out.println("*");
				} else {
					System.out.println(" ");

				}
			}
			System.out.println();
		}
	}	
	}
	

