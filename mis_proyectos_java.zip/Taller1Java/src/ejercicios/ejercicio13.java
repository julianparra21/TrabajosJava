package ejercicios;

public class ejercicio13 {
 public static void main(String[]args) {
	 String nombre="Julian";
	 int documento=1096644178;
	 int edad=17;
	 String profesion="estudiante";
	 System.out.println("Datos ingresados: \n"+"Nombre completo: "+nombre+"\n Documento: "+documento+"\n Edad: "+edad+"\n Profesion: "+profesion+"\n \n Bienvenido!!!");
			 
 }
}
