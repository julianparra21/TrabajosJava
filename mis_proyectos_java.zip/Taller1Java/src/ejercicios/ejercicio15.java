package ejercicios;

public class ejercicio15 {
  public static void main(String[] args) {
	int a=21;
	int b=4;
	int x=a+b*2+a;
	System.out.println(x);
}
}
