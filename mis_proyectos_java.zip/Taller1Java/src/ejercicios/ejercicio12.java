package ejercicios;

public class ejercicio12 {
public static void main(String[]args){
	double nota1= 3.5;
	double nota2= 5.0;
	double nota3=2.3;
    double promedio= (nota1+nota2+nota3)/3;
    System.out.println("el promedio de las tras notas parciales es: "+promedio);
}

}
