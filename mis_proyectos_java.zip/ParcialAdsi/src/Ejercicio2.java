import javax.swing.JOptionPane;

/**
 * Hallar los divisores de un entero positivo dado por el usuario, 
 * este proceso lo deberá realizar las veces que el usuario decida, 
 * para esto debe usar ciclos anidados.
 * @author CHENAO
 *
 */
public class Ejercicio2 {
	
	public void iniciar() {
		String preg="";
		do {
			calcularDivisores();
			preg=JOptionPane.showInputDialog("Desea continuar? Ingrese si");
		} while (preg.equalsIgnoreCase("si"));
			
	}
	

	private void calcularDivisores() {
		int numero=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero"));
		
		if (numero>0) {
			System.out.print("Divisores de "+numero+" = |");
			for (int i = 1; i <= numero; i++) {
				if (numero%i==0) {
					System.out.print(i+" | ");
				}
			}
			System.out.println();
		}else {
			System.out.println("Debe Ingresar numeros enteros positivos");
		}
	}

}
