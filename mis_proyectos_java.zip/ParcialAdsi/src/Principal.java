import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		
		Ejercicio1 ej1=new Ejercicio1();
		Ejercicio2 ej2=new Ejercicio2();
		Ejercicio3 ej3=new Ejercicio3();
		
		String menu="EJERCICIOS\n";
		menu+="1. Ejercicio 1\n";
		menu+="2. Ejercicio 2\n";
		menu+="3. Ejercicio 3\n";
		menu+="4. Salir\n";
		menu+="Ingrese una opción\n";
		
		int opc=0;
		do {
			opc=Integer.parseInt(JOptionPane.showInputDialog(menu));
			switch (opc) {
			case 1:
				ej1.iniciar();
				break;
			case 2:
				ej2.iniciar();
				break;
			case 3:
				ej3.iniciar();
				break;
			case 4:
				break;
			default: System.out.println("No hay más ejercicios, porque se quejan del tiempo!");
				break;
			}
		} while (opc!=4);
		
		
		
		
		
	}

}
