import javax.swing.JOptionPane;

public class Menu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int numero1 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero"));
		int numero2 = Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero"));
		int opcion = 0;
		do {
			String menu = "Menu del Usuario\n\n";
			menu += "1. suma\n";
			menu += "2. resta\n\n";
			menu += "3. Salir";

			opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

			switch (opcion) {
			case 1:
				JOptionPane.showMessageDialog(null, "has seleccionado Suma");
				int suma = numero1 + numero2;
				System.out.println("La suma de los numeros ingresados es: " + suma);
				break;
			case 2:
				JOptionPane.showMessageDialog(null, "Has seleccionado Resta");
				int resta = numero1 - numero2;
				System.out.println("La resta de los numeros ingresados es: " + resta);
				break;
			case 3:
				JOptionPane.showMessageDialog(null, "Salio de nuestro menu", "ERROR", JOptionPane.WARNING_MESSAGE);
				break;
			default:
				System.out.println("Ingrese un valor valido");
				break;

			}
		} while (opcion != 3);

	}

}
