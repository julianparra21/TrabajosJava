import javax.swing.JOptionPane;

public class Principal {

	public static void main(String[] args) {
		int n = Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad de numeros"));
		int num = 0;
		for (int i = 0; i < n; i++) {

			num = Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero"));
			if (num < -2) {
				System.out.println("el numero es menor que -2");
			} else if (num >= -2 && num < 2) {
				System.out.println("el numero es mayor o igual a -2 y pero menor a 2");

			} else if (num >= 2 && num < 5) {
				System.out.println("el numero es mayor o igual a 2 y pero menor a 5");

			} else if (num < 5) {
				System.out.println("el numero es mayor o igual a 5");

			}

		}

	}

}
