import java.util.Iterator;

import javax.swing.JOptionPane;

public class Estudio2 {

	public static void main(String[] args) {

		String preg = "";
		int base, altura, area = 0;

		do {

			do {
				base = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la base"));
				if (base < 0) {
					System.out.println("la base es negativa, ingrese una base positiva");
				}

			} while (base < 0);
			do {
				altura = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la latura"));
				if (altura < 0) {
					System.out.println("La altura es negativa, ingrese una positiva");
				}
			} while (altura < 0);

			area = (base * altura) / 2;
			if (area > 200) {
				System.out.println("Es una gran area");
			}
			System.out.println("el area es: " + area);
			preg = JOptionPane.showInputDialog("Desea continuar");
		} while (preg.equalsIgnoreCase("Si"));
		System.out.println("gracias por utilizar nuestro sistema, gracias");
	}

}
