
public class Principal {
 public static void main(String[] args) {
	 String menu="Gestion de usuarios \n\n";
		menu+="1. Regisrar\n";
		menu+="2. Consultar usuario individual\n";
		menu+="3. Consultar lista de Usuarios\n";
		menu+="4. Actualizar\n";
		menu+="5. Eliminar\n";
		menu+="6. Salir\n\n\n";
		menu+=" Salir";
		
		new Procesos (menu);
 }
}
