import java.util.ArrayList;

import javax.swing.JOptionPane;

public class ModeloDatos {
	ArrayList<String> listaNombre;

	public ModeloDatos() {
		listaNombre = new ArrayList<String>();
	}

	public void registrar(String nombre) {
		listaNombre.add(nombre);
		System.out.println("usuario " + nombre + " Registrado");
		System.out.println();
	}

	public void consultaIndividual(String nombre) {
		if (consultar(nombre) == true) {
			System.out.println(nombre + " si se encuentra Registrado");
		}
	}

	public void consultarLista() {
		if (listaNombre.isEmpty() == false) {
			for (int i = 0; i < listaNombre.size(); i++) {
				System.out.println(listaNombre.get(i) + " Esta en la posicion " + i);
			}
		} else {
			System.out.println("no hay datos registrados");
		}
	}

	public void actulizar(String nombre) {
		if (consultar(nombre)) {
			int pos = listaNombre.indexOf(nombre);
			String nuevoNombre = JOptionPane.showInputDialog("Ingrese el nuevo nombre");
			listaNombre.set(pos, nuevoNombre);

		}
	}
	public void eliminar(String nombre) {
		if (consultar(nombre)) {
			listaNombre.remove(nombre);
			
		}
		System.out.println();
		consultarLista();
	}

	public boolean consultar(String nombre) {
		if (listaNombre.contains(nombre)) {
			return true;
		}else {
			System.out.println(nombre+" No se encuentra registrado");
		return false;
		}
	}
	

}
