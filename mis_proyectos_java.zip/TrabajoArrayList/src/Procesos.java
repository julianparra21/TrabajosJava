import javax.swing.JOptionPane;

public class Procesos {
ModeloDatos miModelo;

public Procesos(String menu) {
	int cod=0;
	do {
		cod=Integer.parseInt(JOptionPane.showInputDialog("menu"));
		logicaMenu(cod);
	} while (cod!=6);
}

private void logicaMenu(int codigo) {

	// TODO Auto-generated method stub
	switch (codigo) {
	case 1:
		String nombre=JOptionPane.showInputDialog("Ingrese el nombre");
		miModelo.registrar(nombre);
		break;
		
	case 2:
		String nombreAConsultar=JOptionPane.showInputDialog("ingrese el nombre que quiere consultar");
		miModelo.consultaIndividual(nombreAConsultar);
		break;
	case 3:
		miModelo.consultarLista();
		break;
	case 4: 
		String nombreActual=JOptionPane.showInputDialog("ingrese el nombre que quiere actualizar");
		miModelo.actulizar(nombreActual);
		break;
	case 5:
		String nombreEliminar=JOptionPane.showInputDialog("ingrese el nombre que quiere eliminar");
		miModelo.eliminar(nombreEliminar);
		break;
	case 6:
		System.out.println("CHAO");
		break;
		
	default:
		System.out.println("No existe la opcion");
		break;
	}
}
}
