import javax.swing.JOptionPane;

public class Estudio1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=0;
		int n=Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de alumnos de los que quiere calcular el promedio de sus notas"));
		do {
		int nota1=Integer.parseInt(JOptionPane.showInputDialog("ingrese la primera nota"));
		int nota2=Integer.parseInt(JOptionPane.showInputDialog("ingrese la segunda  nota"));
		int nota3=Integer.parseInt(JOptionPane.showInputDialog("ingrese la tercera nota"));
		int promedio=(nota1+nota2+nota3)/3;
		if (promedio>=70) {
			System.out.println("APROBADO");
		}else {
			System.out.println("REPROBADO");
			
		}
		i++;
		} while (i<n);
		System.out.println("fin del programa");
	}

}
