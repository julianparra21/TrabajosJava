import javax.swing.JOptionPane;

public class Estudio3 {

	public static void main(String[] args) {
		String preg = "";
		int i = 0;
		String nombre = "";
		int edad = 0;
		int salario = 0;
		do {

			nombre = JOptionPane.showInputDialog("Ingrese su nombre");
			do {
				edad = Integer.parseInt(JOptionPane.showInputDialog("ingrese la edad"));
				if (edad < 0 || edad >= 100) {
					System.out.println(
							"La edad debe ser positiva y menor que 100, por favor ingrese una positiva y menor que 100");
				}
			} while (edad < 0 || edad >= 100);

			do {
				salario = Integer.parseInt(JOptionPane.showInputDialog("Ingrese su salario"));
				if (salario < 0) {
					System.out.println("El salario debe ser positivo");

				}
			} while (salario < 0);

			System.out.println("El usuario " + nombre + " tiene " + edad + " años de edad y su salario es: " + salario);
			preg = JOptionPane.showInputDialog("Desea continuar? si/no");
			i++;
		} while (preg.equalsIgnoreCase("Si"));
	}

}
