import javax.swing.JOptionPane;
public class Algoritmo4 {
public static void main(String[] args) {
	int lineas=Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad"));
	for (int i = 1;i <(lineas/2)+1; i++) {
	for (int j = 0; j <i; j++) {
		System.out.println("*");	
	}	
	System.out.println("\n");
	
	}
	for (int i = (lineas/2); i >0; i--) {
		for (int j = 0; j <i; j++) {
			System.out.println("*");
		}
		System.out.println("\n");
	}
}
}
