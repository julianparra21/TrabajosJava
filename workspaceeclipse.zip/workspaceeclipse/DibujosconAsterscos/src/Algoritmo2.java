import java.util.Scanner;
public class Algoritmo2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner leer= new Scanner (System.in);
		 System.out.println("introduce el numero de pisos");
		 int n=leer.nextInt();
		 n=n*2-1;
		 for (int i = 1; i <=n; i+=2) 
		 {
			for (int j = 1; j < n-1; j+=2) {
				System.out.println(" ");
			}
			for (int k = 1; k <=1; k++) 
			{
				System.out.println("*");
			}
			System.out.println();
		}
	}
}


