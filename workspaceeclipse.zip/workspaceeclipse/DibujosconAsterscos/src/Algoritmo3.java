import javax.swing.JOptionPane;
public class Algoritmo3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		     int valor=Integer.parseInt(JOptionPane.showInputDialog("ingrese el numero de niveles"));
			 int nivel=(valor);
			 int contador;
			 String asterisco="";
			 
			 for ( contador = 1; contador <=nivel; contador++) {
				 asterisco+="*";
				 System.out.println(asterisco);
				
			}

			}
	}


