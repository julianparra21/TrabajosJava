import javax.swing.JOptionPane;
public class Algoritmo5 {
 public static void main(String[] args) {
	 int lineas=Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad"));
		int contador=1;
	    for (int i = 1; i <=lineas; i++) {
		contador++;
		for (int j = 1; j <=contador; j++) {
			for (int k = 0; k <=j; k++) {
				System.out.println("*");
				
			}
			System.out.println("\n");
			
		}
		}
	    System.out.println("**");
	    System.out.println("**");
	    System.out.println("**");
	    System.out.println("**");
}
}
