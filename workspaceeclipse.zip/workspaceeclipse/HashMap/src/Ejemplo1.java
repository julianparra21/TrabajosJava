import java.util.HashMap;
import java.util.Iterator;

public class Ejemplo1 {
 public static void main(String[] args) {
	HashMap<Integer, String> map= new HashMap<>();
	map.put(670, "Julian");
	map.put(340, "David");
	System.out.print(map);
	map.put(670,"Ospina");
	
	
	imprimirMapa(map);
}

private static void imprimirMapa(HashMap<Integer, String> map) {
	// TODO Auto-generated method stub
	System.out.println(map);
	
	Iterator<Integer>iterator=map.keySet().iterator();
	
	while (iterator.hasNext()){
		Integer llave= iterator.next();
		System.out.println(llave+ " - "+map.get(llave));
	}
	
}
}
