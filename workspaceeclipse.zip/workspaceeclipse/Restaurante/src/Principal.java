import javax.swing.JOptionPane;
public class Principal {
public static void main(String args[]) {
	String nombres[]=new String[5];
	nombres[0]=JOptionPane.showInputDialog("ingrese el nombre");
	nombres[1]="Juan";
	nombres[2]="Maria";
	nombres[3]="Carlos";
	nombres[4]="Luis";
	nombres[2]="Silvana";
	
	
	
	
	System.out.println("el Nombre ingresado es:"+nombres[0]);
	
}
}
