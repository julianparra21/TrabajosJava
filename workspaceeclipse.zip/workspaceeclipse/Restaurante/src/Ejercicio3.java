import javax.swing.JOptionPane;

public class Ejercicio3 {

	public static void main(String[] args) {
		
		String menu="MENU ESTUDIANTES\n\n";
				menu+="1. Registrar estudiantes\n";
				menu+="2. Imprimir lista estudiantes\n";
				menu+="3. imprimir lista notas\n";
				menu+="4. salir\n\n";
				menu+="seleecione una opcion";
				
				int n=Integer.parseInt(JOptionPane.showInputDialog("ingrese la cantidad de estudiantes a procesar"));
				double n1=0,n2=0,n3=0;
				String nombre="";
				String nombres[]=new String[n];
				double notas[]=new double[n];
		int opc=0;
		do {
			 opc=Integer.parseInt(JOptionPane.showInputDialog(menu));
			 switch (opc) {
				case 1: for (int i = 0; i < nombres.length; i++) {
					 nombre=JOptionPane.showInputDialog("ingrese el nombre del estudiante "+(i+1));
						
						nombres[i]=nombre;
						n1=Double.parseDouble(JOptionPane.showInputDialog("ingrese la nota 1 del estudiante "+nombres[i]));
						n2=Double.parseDouble(JOptionPane.showInputDialog("ingrese la nota 2 del estudiante "+nombres[i]));
						n3=Double.parseDouble(JOptionPane.showInputDialog("ingrese la nota 3 del estudiante "+nombres[i]));
						
						double promedio= (n1+n2+n3)/3;
						notas[i]=promedio;
						
						if (promedio>=3.5) {
							System.out.println("gana la materia");
							
						}else {
							System.out.println("pierde la materia");
						}
					}
		;
				case 2:
					for (int i = 0; i < notas.length; i++) {
						System.out.println(nombres[i]+ "nota Final "+notas[i]+" | " );
					}
					;
				case 3:
					for (int i = 0; i < notas.length; i++) {
						System.out.println(nombres[i]+ "nota Final "+notas[i]+" | " );
					}
					;
				case 4:
					System.out.println("chao");
					
					break;
				default:System.out.println("la opcion no existe");
					
				}
		} while (opc!=4);
		
	
	
	}

}
