import java.util.Iterator;

import javax.swing.JOptionPane;

public class ejemplo2 {

	public static void main(String[] args) {
		int n=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el numero de personas"));
		String nombres[]=new String[n];
		int edad[]=new int[n];
		for (int i = 0; i < nombres.length; i++) {
			nombres[i]=JOptionPane.showInputDialog("ingrese el nombre");
			edad[i]=Integer.parseInt(JOptionPane.showInputDialog("ingrese la edad"));
			
		}
		
		for (int i = 0; i < nombres.length; i++) { 
			System.out.println("Su nombre es: "+nombres[i]+" Y su edad es: "+edad[i]);;
			
		}
		
	
			
		}
	
	}


