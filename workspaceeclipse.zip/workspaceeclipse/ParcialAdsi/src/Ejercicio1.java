import java.util.ArrayList;
import java.util.HashMap;

import javax.swing.JOptionPane;

public class Ejercicio1 {
	
	ArrayList<String> nombresList=new ArrayList<String>();
	ArrayList<Double> comisionList= new ArrayList<Double>();
	
	HashMap<String, Double> mapaPersonas=new HashMap<String, Double>();
	
	String menu="";

	public void iniciar() {
		
		menu="MENU TIPO EMPLEADO\n";
		menu+="1. Tipo A\n";
		menu+="2. Tipo B\n";
		menu+="3. Tipo C\n";
		menu+="4. Tipo D\n";
		menu+="5. Imprimir Lista\n";
		menu+="6. Salir\n";
		menu+="Ingrese una opción\n";

		iniciarMenu();
	}

	private void iniciarMenu() {
		int cod=0;
		do {
			cod=Integer.parseInt(JOptionPane.showInputDialog(menu));
			if (cod!=6) {
				if (cod!=5) {
					seleccionarOpcion(cod);	
				}else {
					//imprimirLista();
					System.out.println(mapaPersonas);
				}
				
			}	
		} while (cod!=6);
	
	}

	private void seleccionarOpcion(int cod) {
		String nombre="";
		double porComision=0;
		double ventas=0;
		double comision=0;
		

			nombre=JOptionPane.showInputDialog("Ingrese el nombre de la persona");
			nombresList.add(nombre);
			porComision=0;
			ventas=Double.parseDouble(JOptionPane.showInputDialog("Ingrese las ventas"));
			comision=0;
	
		switch (cod) {
		case 1:System.out.println("Tipo A");
			porComision=0.08;
			break;
		case 2:System.out.println("Tipo B");
			porComision=0.06;
			break;
		case 3:System.out.println("Tipo C");
			porComision=0.04;
			break;
		case 4:System.out.println("Tipo D");
			porComision=0.02;
			break;
		case 5:
			break;
		case 6:System.out.println("Salir");
		break;
		default: System.out.println("No existe la opción");
			break;
		}

			comision=ventas*porComision;
			comisionList.add(comision);

			mapaPersonas.put(nombre, comision);
			System.out.println(nombresList);
			System.out.println(comisionList);
			System.out.println("");
			String mensaje="FACTURA DE PAGO:\n";
			mensaje+="Las ventas fueron: $"+ventas+"\n";
			mensaje+="El % de comisión es de: "+(porComision*100)+"%\n";
			mensaje+="La comisión es de: $"+comision+"\n";
			System.out.println(mensaje);
			System.out.println("------------------------------------");
		
	}

	private void imprimirLista() {
		
		if (nombresList.isEmpty()==false) {
			for (int i = 0; i < nombresList.size(); i++) {
				System.out.println(nombresList.get(i)+" con comisión de "+comisionList.get(i));
			}
		}else {
			System.out.println("Debe registrar elementos");
		}
		
		

	}
	
}
