import javax.swing.JOptionPane;

/**
 * 
 * Cree un algoritmo que calcule e imprima lo que debe pagar un paciente a 
 * un hospital debido a un tratamiento teniendo como entradas el costo del
 * tratamiento, el número de días de Hospitalización y el costo de los 
 * medicamentos. Cada día de hospitalización cuesta $100000.
 * Realice este proceso para n cantidad de usuarios.
 * 
 * @author CHENAO
 *
 */
public class Ejercicio3 {

	public void iniciar() {
		int n=Integer.parseInt(JOptionPane.showInputDialog("Ingrese la cantidad de pacientes"));
		
		int i=0;
		do {
			calcularTratamiento();
			i++;
		} while (i<n);
	}
	

	
	private void calcularTratamiento(){
		String nombrePaciente=JOptionPane.showInputDialog("Ingrese el nombre del paciente");
		double costoTrat=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el costo del tratamiento"));
		int diasHospital=Integer.parseInt(JOptionPane.showInputDialog("Ingrese los dias de Hospital"));
		double costoMedicamentos=Double.parseDouble(JOptionPane.showInputDialog("Ingrese el costo de los medicamentos"));
		double valorHospitalizacion=diasHospital*100000;
		
		
		imprimirFactura(nombrePaciente,costoTrat,costoMedicamentos,valorHospitalizacion);
	}

	private void imprimirFactura(String nombrePaciente, double costoTrat, 
			double costoMedicamentos, double valorHospitalizacion) {
		
		double pago=costoTrat+costoMedicamentos+valorHospitalizacion;
		
		String cad="FACTURA\n";
		cad+="Nombre: "+nombrePaciente+"\n";
		cad+="Costo Tratamiento: "+costoTrat+"\n";
		cad+="Costo Medicamentos: "+costoMedicamentos+"\n";
		cad+="Costo Hospitalización: "+valorHospitalizacion+"\n";
		cad+="Costo Total: "+pago+"\n";

		System.out.println(cad);
		System.out.println("-------------------------------------\n");
		

		
	}
	
}
