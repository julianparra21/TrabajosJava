	package ejercicios;

public class ejercicio2 {
	public static void main(String[]args) {
 int c=8;
 int a=2;
 int b= -2;
 c= (a*b)+2;
 a=a-2+b*(b+3)-c;
 b=c;
  System.out.println(a+b+c);
	}
}
