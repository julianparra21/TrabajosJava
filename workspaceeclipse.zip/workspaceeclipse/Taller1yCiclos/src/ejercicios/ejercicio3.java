package ejercicios;

public class ejercicio3 {
 public static void main (String[]args) {
	 final int PAGO=2000;
	 double porcentaje=15;
	 double calculo= porcentaje*PAGO/100;
	 System.out.println("El valor de la constante es: "+calculo);
 }
}
