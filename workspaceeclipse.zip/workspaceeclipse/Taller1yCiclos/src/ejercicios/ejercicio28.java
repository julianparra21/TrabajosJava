package ejercicios;

import javax.swing.JOptionPane;

public class ejercicio28 {
 public static void main(String[]args) {
	 int monto=30,
	 interes=50,
			 plazo=3;
	 int rendimiento=monto*interes*plazo/360;
	 System.out.println(rendimiento);
	 
	 System.out.println();
	
	 
 }
}
