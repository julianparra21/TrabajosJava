import javax.swing.JOptionPane;
public class Examen1 {
	

	

		public static void main(String[] args) {
			
			String nombre =JOptionPane.showInputDialog("Ingrese su nombre");
			int venta =Integer.parseInt(JOptionPane.showInputDialog("Ingrese sus ventas mensuales"));
			
			int opcion=0;
		
			
			do {
				String menu="Menu Tipo de Vendedor \n";
				menu+="1. A = Comision 8% \n";
				menu+="2. B = Comision 6% \n";
				menu+="3. C = Comision 4% \n";
				menu+="4. D = Comision 2% \n";
				menu+="5. Salir \n";
				menu+="Escoga una opcion, por favor";
				opcion=Integer.parseInt(JOptionPane.showInputDialog(menu));
				
				double comision=0;
				
				switch (opcion) {
				case 1:
					JOptionPane.showMessageDialog(null, "Has seleccionado comision 8%","comision 8%",JOptionPane.INFORMATION_MESSAGE);
					System.out.println("Tipo de vendedor a ,comision 8%");
					comision=venta * 0.08;
					System.out.println("Hola "+ nombre+" sus ventas en el mes fueron de :"+venta+"por eso usted recibira una comision de :"+ comision);
					break;
				case 2 :
					JOptionPane.showMessageDialog(null, "Has seleccionado comision 8%","comision 8%",JOptionPane.INFORMATION_MESSAGE);
					System.out.println("Tipo de vendedor b ,comision 6%");
					comision=venta * 0.06;
					System.out.println("Hola "+ nombre+" sus ventas en el mes fueron de :"+venta+"por eso usted recibira una comision de :"+ comision);
					break;
				case 3:
					JOptionPane.showMessageDialog(null, "Has seleccionado comision 8%","comision 8%",JOptionPane.INFORMATION_MESSAGE);
					System.out.println("Tipo de vendedor c ,comision 4%");
					comision=venta * 0.04;
					System.out.println("Hola "+ nombre+" sus ventas en el mes fueron de :"+venta+"por eso usted recibira una comision de :"+ comision);
					break;
				case 4:
					JOptionPane.showMessageDialog(null, "Has seleccionado comision 8%","comision 8%",JOptionPane.INFORMATION_MESSAGE);
					System.out.println("Tipo de vendedor d ,comision 2%");
					comision=venta * 0.08;
					System.out.println("Hola "+ nombre+" sus ventas en el mes fueron de :"+venta+"por eso usted recibira una comision de :"+ comision);
					break;
				case 5:
					JOptionPane.showMessageDialog(null, "�SALIO DEL SISTEMA!","ERROR",JOptionPane.WARNING_MESSAGE);
					break;

				default:
					System.out.println("Ingrese tipo de vendedor valido");
					break;
				}
				
			} while (opcion!=5);
			
			
			
		}
	

}
