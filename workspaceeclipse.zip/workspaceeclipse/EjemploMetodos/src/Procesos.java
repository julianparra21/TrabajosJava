
public class Procesos {

	public void otroMetodo() {
		System.out.println("Hola,este es otro metodo");
	}
	public  void saludar() {
		 System.out.println("Hola este es un saludo");
	 }
	
}
