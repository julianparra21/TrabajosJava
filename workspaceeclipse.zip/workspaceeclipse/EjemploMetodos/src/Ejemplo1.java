
public class Ejemplo1 {
 public static void main(String[] args) {
	Procesos miProceso=new Procesos();
	miProceso.saludar();
	miProceso.otroMetodo();
	
}
 
}
