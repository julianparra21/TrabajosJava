

public class ejemploMatematicas {

	public static void main(String[] args) {
  Aplicacion miAplicacion= new Aplicacion();
  miAplicacion.iniciar();
  
  
	}
	

}
