import javax.swing.JOptionPane;

public class operaciones {
 public void sumar() {
	
	 int x=Integer.parseInt(JOptionPane.showInputDialog("ingrese el primer numero: "));
	 int y=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
	 int sumar=(x+y);
	 System.out.println("la suma de los dos numeros ingresados es: "+sumar);
 }
 public void restar() {
	
	 int x=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero: "));
	 int y=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
	 int resta=(x-y);
	 System.out.println("la resta de los dos numeros es: "+resta);
 }
public void dividir() {
	
	int x=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero: "));
	int y=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
	int dividir=(x/y);
	System.out.println("La division de los dos numeros es: "+dividir);
}
public void multiplicar() {
	
	int x=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el primer numero: "));
	int y=Integer.parseInt(JOptionPane.showInputDialog("Ingrese el segundo numero: "));
	int multiplicar=(x*y);
	System.out.println("La multiplicacion de los dos numeros es: "+multiplicar);
	
}
}
