import javax.swing.JOptionPane;

public class Aplicacion {
	public void iniciar() {
		 crearMenu();
	 }
	operaciones misOperaciones= new operaciones();
	private void crearMenu() {
		String menu="MENU OPERACIONES \n\n";
		menu+="1. Sumar\n";
		menu+="2. Restar\n";
		menu+="3. Multiplicar\n";
		menu+="4. Dividir\n";
		menu+="5. Salir\n\n\n";
		menu+="selecciona una opcion";
		int cod=0;
		do {
			cod=Integer.parseInt(JOptionPane.showInputDialog(menu));
			presentarOpciones(cod);
		} while (cod!=5); 
	}

	private void presentarOpciones(int cod) {
		switch (cod) {
		case 1:
			JOptionPane.showMessageDialog(null, "Has seleccionado Suma","Suma",JOptionPane.INFORMATION_MESSAGE);
			misOperaciones.sumar();
			 
			break;
		case 2:
			JOptionPane.showMessageDialog(null, "Has seleccionado Resta","Resta",JOptionPane.INFORMATION_MESSAGE);
			misOperaciones.restar();
			break;
		case 3:
			JOptionPane.showMessageDialog(null, "Has seleccionado Multiplicacion","Multiplicacion",JOptionPane.INFORMATION_MESSAGE);
			misOperaciones.multiplicar();
			break;
		case 4:
			JOptionPane.showMessageDialog(null, "Has seleccionado Division","Division",JOptionPane.INFORMATION_MESSAGE);
			misOperaciones.dividir();
			break;
			
		case 5:
			JOptionPane.showMessageDialog(null, "Has seleccionado Salir","Salir",JOptionPane.INFORMATION_MESSAGE);
			break;
		default:
			break;
		}
	}
	
}
